# Ibrahim Khel Welfare Android V1

یہ Android Studio project ہے۔
Application ID: com.ibrahimkhel.welfare
Version: 1.0

اہم: اس فولڈر کو Android Studio/Gradle build environment میں کھول کر APK build کیا جا سکتا ہے۔
موجودہ HTML app `app/src/main/assets/index.html` میں شامل ہے۔
